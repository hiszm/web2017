<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/





// Route::post('/', function () {
//     echo 'post';
// });

// Route::put('/', function () {
//     echo 'put';
// });


// Route::any('/', function () {
//     echo 'any';
// });

// Route::get('/user/{id}', function ($id) {
//     return 'User '.$id;
// });

// Route::get('/posts/{post}/comments/{comment}', function ($postId, $commentId) {
//     echo "postID=".$postId."  comment=".$commentId;
// });
// Route::get('/user/{name?}', function ($name = 'jarry') {
//     return $name;
// })->where('name', '[A-Za-z]+');

// Route::get('/user/{id}','IndexController@index');

// Route::get('/admin/{id}','Admin\AdminController@index');

//Route::get('test', ['uses' => 'IndexController@index', 'as' => 'name']);

// Route::get('test', ['as' => 'name',function(){
//     echo route('name');

// }]);

// Route::get('/admin/index','Admin\AdminController@index');
// Route::get('/admin/view1','Admin\AdminController@view1');
// Route::get('/admin/view2','Admin\AdminController@view2');
// Route::get('/admin/view3','Admin\AdminController@view3');

// Route::group( ['prefix' => 'admin','namespace'=>'Admin','middleware'=>['web','admin.login']],function(){
//    Route::get('index','AdminController@index');
   

// });
// Route::group( ['prefix' => 'admin','namespace'=>'Admin','middleware'=>['web']],function(){
 
//    Route::get('login','AdminController@login');

// });

// Route::resource('book', 'BookController');

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/

Route::group(['middleware' => ['web']], function () {

    // Route::get('/', function () {

    // session(['key'=>1337]);
   
    // return view('welcome');
    // });

    // Route::get('/key', function () {

    // echo session('key');
    // });
    //
});
