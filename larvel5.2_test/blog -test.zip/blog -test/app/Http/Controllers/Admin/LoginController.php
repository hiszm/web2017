<?php

namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;

// use Illuminate\Support\Facades\DB;
use DB;

class AdminController extends CommonController
{
  
    public function index()
    {
       echo 'ok';

    }


    
}