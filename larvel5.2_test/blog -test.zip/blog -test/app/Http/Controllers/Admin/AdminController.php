<?php

namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;

// use Illuminate\Support\Facades\DB;
use DB;

class AdminController extends Controller
{
  
    public function index()
    {
       $data=array(
                  
                   'num'=>70,
                   'n'=>10
         );

        $users=array(
                  
                   'id'=>array(1,2,3,4,5,6,7)
                   
         );

         $test3='test3';
        return view('admin.admin',compact('data','users'));


    }


    public function login()
    {
        // echo 'admin->login<br/ >';
        // session(['admin'=>1337]);
        // $pdo=DB::connection()->getPdo();
        // dd($pdo);
        $user=DB::table('user')->where('user_id',1)->get();
        dd($user);
        echo "hi";

    }


    public function view1(){

        return view('admin.view1');
    }


    public function view2(){

        return view('admin.view2');
    }

     public function view3(){

        return view('admin.view3');
    }
}