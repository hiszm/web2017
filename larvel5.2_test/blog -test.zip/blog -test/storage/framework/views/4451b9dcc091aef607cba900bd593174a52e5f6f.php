<?php $__env->startSection('df'); ?>
    @parent
    <h1> 不同的</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>