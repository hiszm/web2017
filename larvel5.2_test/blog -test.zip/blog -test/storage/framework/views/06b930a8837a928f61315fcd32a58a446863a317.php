 <h1>这里是公共部分--头部<?php echo e($page); ?></h1>
      <?php echo $__env->yieldContent('df'); ?>
 <h1>这里是公共部分--头尾</h1>