<html>
    <body>
        <h1>
            <!--<?php if($data['num'] >80): ?>
            
                good
    
            <?php else: ?>
                bad
            <?php endif; ?>-->
        
<!--        
            <?php if ( ! ($data['num'] < 60)): ?>
             good
            <?php endif; ?>-->


<!--
            <?php for($i = 0; $i < 10; $i++): ?>
                The current value is <?php echo e($i); ?> <br/>
            <?php endfor; ?>
            <hr/>-->
           

        </h1>

<!--
        <?php foreach($users['id'] as $k=> $v): ?>
            <p><?php echo e($k); ?>==><?php echo e($v); ?></p>
        <?php endforeach; ?>-->
<!--
        <?php $__empty_1 = true; foreach($users['id'] as $v): $__empty_1 = false; ?>
            <li>ID:<?php echo e($v); ?></li>
            <?php endforeach; if ($__empty_1): ?>
            <p>No users</p>
        <?php endif; ?>-->
        <!--<?php echo e($i=6); ?>

        <?php while($i): ?>
            <?php echo e($i--); ?>

        <?php endwhile; ?>-->
      
    </body>
</html>