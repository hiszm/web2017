<html>
    <body>
<h1>这里是公共部分--头部</h1>
      <!--<?php echo $__env->yieldContent('df'); ?>-->

      <?php $__env->startSection('df'); ?>
      <h1>parent</h1>
      <?php echo $__env->yieldSection(); ?>
      
 <h1>这里是公共部分--头尾</h1>
    </body>
</html>