<html>
    <body>
        <h1>
            <!--@if($data['num'] >80)
            
                good
    
            @else
                bad
            @endif-->
        
<!--        
            @unless ($data['num'] < 60)
             good
            @endunless-->


<!--
            @for ($i = 0; $i < 10; $i++)
                The current value is {{ $i }} <br/>
            @endfor
            <hr/>-->
           

        </h1>

<!--
        @foreach ($users['id'] as $k=> $v)
            <p>{{$k}}==>{{ $v }}</p>
        @endforeach-->
<!--
        @forelse ($users['id'] as $v)
            <li>ID:{{ $v }}</li>
            @empty
            <p>No users</p>
        @endforelse-->
        <!--{{$i=6}}
        @while ($i)
            {{$i--}}
        @endwhile-->
      
    </body>
</html>